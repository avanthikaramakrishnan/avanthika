function submitData(){
    var name=document.getElementById('name').Value
    var dob=document.grtElementById('dob').Value
    console.log(name+""+dob)
    var output=document.getElementById('output');
    output.innerText
}